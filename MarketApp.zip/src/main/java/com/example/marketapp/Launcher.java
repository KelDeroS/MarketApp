package com.example.marketapp;

public class Launcher {
    public static void main(String[] args) {
        MarketAppMain.main(args);
    }
}
